/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dma.h"
#include "usart.h"
#include "gpio.h"
#include "arm_math.h"
#include "math.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "my_uart.h"
#include "filter.h"
#include "get_features.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
int16_t count = 0;								
float32_t fir_put[500][3];											//滤波输出数据
float32_t a1,a2,a3;
float32_t acc_x,acc_y,acc_z,gyro_x,gyro_y,gyro_z;
float32_t	acc_neck_x,acc_neck_y,acc_neck_z;

int32_t headdown,headup,headright,headleft;

float32_t  feature[30]={0};
uint32_t Index[12];
int result_array[10] ={0};
int decide_array[8] = {0};
int temp = 0;
int n = 0;
uint16_t i;
uint16_t j;
uint16_t result[8]={0};
uint16_t result_two[5] ={0};

// 获取6轴数据
float32_t   acc_x_array[114];
float32_t   acc_y_array[114];
float32_t   acc_z_array[114];
float32_t   gyro_x_array[114];
float32_t 	 gyro_y_array[114];
float32_t   gyro_z_array[114];


/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void USART2_IRQHandler(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  
  HAL_Init();
  SystemClock_Config();
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_DMA_Init();
  MX_USART3_UART_Init();
	User_USART_Init(&JY901_data);
//	printf("test!!\r\n");
	
//	static uint16_t i;
	int flag = 1;
	char ch1;
	int flag1;
//	bt_tx_data(headdown,headup,headright,headleft);
	
//	HAL_UART_Receive_IT(&huart2, (unsigned char *)&value,1);


  while (1)
  {
		if(flag == 1)
		{
			HAL_Delay(2000);
			for(i=0;i<500;i++)
				{
					fir_put[i][0] = sliding_average_filter1(JY901_data.acc.a[0]);
					fir_put[i][1] = sliding_average_filter2(JY901_data.acc.a[1]);
					fir_put[i][2] = sliding_average_filter3(JY901_data.acc.a[2]);
					
					HAL_Delay(1);
					
			
					acc_neck_x = fir_put[i][0] + acc_neck_x;
					acc_neck_y = fir_put[i][1] + acc_neck_y;
					acc_neck_z = fir_put[i][2] + acc_neck_z;
					HAL_Delay(1);
				}
			flag = 0;
			acc_neck_x = acc_neck_x/500;
			acc_neck_y = acc_neck_y/500;
			acc_neck_z = acc_neck_z/500;
		
				
			for(i=0;i<8;i++)
			{
				HAL_Delay(5);
				result[i]=0;
			}
		}
				
//			printf("%f,%f,%f\r\n",y1,y2,y3);	
		
		
//		printf("%f,%f,%f,%f,%f,%f\r\n",(JY901_data.acc.a[0]),(JY901_data.acc.a[1]),(JY901_data.acc.a[2]),JY901_data.w.w[0],JY901_data.w.w[1],JY901_data.w.w[2]);	
//		printf("%f,%f,%f\r\n",a1,a2,a3);
		
		
//		acc_x = sliding_average_filter1(JY901_data.acc.a[0]) - acc_neck_x;
//		acc_y = sliding_average_filter2(JY901_data.acc.a[1]) - acc_neck_y;
//		acc_z = sliding_average_filter3(JY901_data.acc.a[2]) - acc_neck_z;

//		gyro_x = sliding_average_filter4(JY901_data.w.w[0]);
//		gyro_y = sliding_average_filter5(JY901_data.w.w[1]);
//		gyro_z = sliding_average_filter6(JY901_data.w.w[2]);
//					
//		printf("%f,%f,%f,%f,%f,%f\r\n",acc_x,acc_y,acc_z,gyro_x,gyro_y,gyro_z);
//		HAL_Delay(20);

		
		
		// 单次识别
		ch1=getchar();
//		printf("%c\n",ch);
		
		switch(ch1)
		{
			case '0': flag1 = 2;	break;
			case '1': flag1 = 1;	break;
		}
		if(flag1 == 1)
		{
//			printf("111\r\n");
			for(i=0;i<8;i++)
			{
				HAL_Delay(5);
				decide_array[i]=0;
			}

			
//			HAL_Delay(300);
			printf("8");
			for(i=0;i<114;i++)
			{
				acc_x = sliding_average_filter1(JY901_data.acc.a[0]) - acc_neck_x;
				acc_y = sliding_average_filter2(JY901_data.acc.a[1]) - acc_neck_y;
				acc_z = sliding_average_filter3(JY901_data.acc.a[2]) - acc_neck_z;
				gyro_x = sliding_average_filter4(JY901_data.w.w[0]);
				gyro_y = sliding_average_filter5(JY901_data.w.w[1]);
				gyro_z = sliding_average_filter6(JY901_data.w.w[2]);
				
				
				acc_x_array[i]  = acc_x;
				acc_y_array[i]  = acc_y;
				acc_z_array[i]  = acc_z;					
				gyro_x_array[i] = gyro_x;
				gyro_y_array[i] = gyro_y;
				gyro_z_array[i] = gyro_z;
				HAL_Delay(20);
				
//				printf("%f,%f,%f,%f,%f,%f\r\n",acc_x_array[i],acc_y_array[i],acc_z_array[i],gyro_x_array[i],gyro_y_array[i],gyro_z_array[i]);
			}
			printf("9");
//		printf("\n");
		// 特征提取
		//0-14
		// acc_body_x
			arm_min_f32(acc_x_array,114,&feature[0],&Index[0]);
			arm_max_f32(acc_x_array,114,&feature[1],&Index[1]);
			arm_mean_f32(acc_x_array,114,&feature[2]);
			arm_std_f32(acc_x_array,114,&feature[3]);
			feature[4] = get_energy(acc_x_array,114);
		// acc_body_y
			arm_min_f32(acc_y_array,114,&feature[5],&Index[2]);
			arm_max_f32(acc_y_array,114,&feature[6],&Index[3]);
			arm_mean_f32(acc_y_array,114,&feature[7]);
			arm_std_f32(acc_y_array,114,&feature[8]);
			feature[9] = get_energy(acc_y_array,114);
		// acc_body_z
			arm_min_f32(acc_z_array,114,&feature[10],&Index[4]);
			arm_max_f32(acc_z_array,114,&feature[11],&Index[5]);
			arm_mean_f32(acc_z_array,114,&feature[12]);
			arm_std_f32(acc_z_array,114,&feature[13]);
			feature[14] = get_energy(acc_z_array,114);
			
		//15-29
		//gyro_x
			arm_min_f32(gyro_x_array,114,&feature[15],&Index[6]);
			arm_max_f32(gyro_x_array,114,&feature[16],&Index[7]);
			arm_mean_f32(gyro_x_array,114,&feature[17]);
			arm_std_f32(gyro_x_array,114,&feature[18]);
			feature[19] = get_energy(gyro_x_array,114);
		//gyro_y
			arm_min_f32(gyro_y_array,114,&feature[20],&Index[8]);
			arm_max_f32(gyro_y_array,114,&feature[21],&Index[9]);
			arm_mean_f32(gyro_y_array,114,&feature[22]);
			arm_std_f32(gyro_y_array,114,&feature[23]);
			feature[24] = get_energy(gyro_y_array,114);
		//gyro_z
			arm_min_f32(gyro_z_array,114,&feature[25],&Index[10]);
			arm_max_f32(gyro_z_array,114,&feature[26],&Index[11]);
			arm_mean_f32(gyro_z_array,114,&feature[27]);
			arm_std_f32(gyro_z_array,114,&feature[28]);
			feature[29] = get_energy(gyro_z_array,114);
					
		if(fabs(fabs(feature[0])-fabs(feature[1]))<0.1 && fabs(fabs(feature[5])-fabs(feature[6]))<0.1 && fabs(fabs(feature[10])-fabs(feature[11]))<0.1)
		{
			printf("10\r\n");
		}
		else
		{	
		// 随机森林算法
		// tree0
		if(feature[11]<=0.422f)
			{
        if (feature[13]<=0.285f)
        {
          if (feature[25]<=-44.8f)
          {
            if (feature[0]<=-0.332f)
            {
              result_array[0]=1;
            }
            else
            {
              result_array[0]=0;
            }
          }
          else
          {
            if (feature[14]<=0.02f)
            {
              result_array[0]=4;
            }
            else
            {
              result_array[0]=3;
            }
          }            
        }
        else
        {
           result_array[0]=7;       
        }        
      }
    else
    {
      if (feature[4]<=0.031f)
      {
        if (feature[23]<=39.376f)
        {
          result_array[0]=2;
        }
        else
        {
          result_array[0]=3;
        }
      }
      else
      {
        result_array[0]=6;
      }
    }

    // tree1
    if (feature[16]<=85.635f)
    {
      if (feature[24]<=198.413f)
      {
        if (feature[1]<=0.463f)
        {
          result_array[1]=1;
        }
        else
        {
          result_array[1]=0;
        }
      }
      else
      {
        if (feature[4]<=0.1f)
        {
          if (feature[10]<=-0.363f)
          {
            result_array[1]=3;
          }
          else
          {
            result_array[1]=2;
          }
        }
        else
        {
          if (feature[6]<=0.064f)
          {
            result_array[1]=6;
          }
          else
          {
            result_array[1]=6;
          }
        }
      }
    }
    else
    {
      if (feature[4]<=0.074f)
      {
        if (feature[23]<=45.177f)
        {
          result_array[1]=2;
        }
        else
        {
          result_array[1]=4;
        }
      }
      else
      {
        result_array[1]=7;
      }
    }

    // tree2
    if (feature[0]<=-0.334f)
    {
      if (feature[12]<=0.061f)
      {
        if (feature[23]<=18.655f)
        {
          result_array[2]=1;
        }
        else
        {
          result_array[2]=7;
        }
      }
      else
      {
        result_array[2]=6;
      }
    }
    else
    {
      if (feature[21]<=27.094f)
      {
        if (feature[24]<=198.98f)
        {
          result_array[2]=0;
        }
        else
        {
          if (feature[21]<=22.437f)
          {
            result_array[2]=3;
          }
          else
          {
            result_array[2]=2;
          }
        }
      }
      else
      {
        if (feature[23]<=47.656f)
        {
          if (feature[19]<=795.013f)
          {
            result_array[2]=3;
          }
          else
          {
            result_array[2]=2;
          }
        }
        else
        {
          if (feature[11]<=0.063f)
          {
            result_array[2]=4;
          }
          else
          {
            result_array[2]=5;
          }
        }
      }
    }

    // tree3
    if (feature[13]<=0.138f)
    {
      if (feature[24]<=331.784f)
      {
        if (feature[9]<=0.025f)
        {
          result_array[3]=0;
        }
        else
        {
          result_array[3]=1;
        }
      }
      else
      {
        if (feature[14]<=0.003f)
        {
          if (feature[3]<=0.032f)
          {
            result_array[3]=4;
          }
          else
          {
            result_array[3]=5;
          }
        }
        else
        {
          if (feature[20]<=-85.965f)
          {
            result_array[3]=4;
          }
          else
          {
            result_array[3]=5;
          }
        }
      }
    }
    else
    {
      if (feature[6]<=0.063f)
      {
        if (feature[10]<=-0.37f)
        {
          if (feature[4]<=0.045f)
          {
            result_array[3]=3;
          }
          else
          {
            result_array[3]=7;
          }
        }
        else
        {
          if (feature[20]<=-24.622f)
          {
            result_array[3]=2;
          }
          else
          {
            result_array[3]=6;
          }
        }
      }
      else
      {
        if (feature[10]<=-0.44f)
        {
          result_array[3]=3;
        }
        else
        {
          result_array[3]=6;
        }
      }
    }

    //  tree4
    if (feature[8]<=0.136f)
    {
      if (feature[3]<=0.122f)
      {
        if (feature[23]<=45.808f)
        {
          if (feature[19]<=838.108f)
          {
            result_array[4]=3;
          }
          else
          {
            result_array[4]=2;
          }
        }
        else
        {
          if (feature[11]<=0.061f)
          {
            result_array[4]=4;
          }
          else
          {
            result_array[4]=5;
          }
        }
      }
      else
      {
        result_array[4]=0;
      }
    }
    else
    {
      if (feature[22]<=-4.648f)
      {
        result_array[4]=7;
      }
      else
      {
        if (feature[12]<=0.059f)
        {
          if (feature[28]<=22.566f)
          {
            result_array[4]=3;
          }
          else
          {
            result_array[4]=1;
          }
        }
        else
        {
          result_array[4]=6;
        }
      }
    }

    //  tree5
    if (feature[26]<=47.647f)
    {
      if (feature[21]<=72.137f)
      {
        if (feature[29]<=57.439f)
        {
          if (feature[12]<=0.041f)
          {
            result_array[5]=5;
          }
          else
          {
            result_array[5]=2;
          }
        }
        else
        {
          if (feature[8]<=0.037f)
          {
            result_array[5]=0;
          }
          else
          {
            result_array[5]=3;
          }
        }
      }
      else
      {
        if (feature[11]<=0.061f)
        {
          if (feature[10]<=-0.092f)
          {
            result_array[5]=4;
          }
          else
          {
            result_array[5]=5;
          }
        }
        else
        {
          if (feature[28]<=11.302f)
          {
            result_array[5]=5;
          }
          else
          {
            result_array[5]=3;
          }
        }
      }
    }
    else
    {
      if (feature[24]<=401.149f)
      {
        if (feature[0]<=-0.328f)
        {
          result_array[5]=1;
        }
        else
        {
          result_array[5]=0;
        }
      }
      else
      {
        if (feature[10]<=-0.517f)
        {
          result_array[5]=7;
        }
        else
        {
          result_array[5]=6;
        }
      }
    }

    //  tree6
    if (feature[12]<=0.053f)
    {
      if (feature[10]<=-0.382f)
      {
        if (feature[9]<=0.069f)
        {
          result_array[6]=3;
        }
        else
        {
          result_array[6]=7;
        }
      }
      else
      {
        if (feature[16]<=39.398f)
        {
          if (feature[11]<=0.052f)
          {
            result_array[6]=0;
          }
          else
          {
            result_array[6]=1;
          }
        }
        else
        {
          if (feature[10]<=-0.098f)
          {
            result_array[6]=4;
          }
          else
          {
            result_array[6]=5;
          }
        }
      }
    }
    else
    {
      if (feature[1]<=0.284f)
      {
        result_array[6]=2;
      }
      else
      {
        result_array[6]=6;
      }
    }

    //  tree7
    if (feature[10]<=-0.703f)
    {
      result_array[7]=7;
    }
    else
    {
      if (feature[10]<=-0.405f)
      {
        result_array[7]=3;
      }
      else
      {
        if (feature[11]<=0.347f)
        {
          if (feature[8]<=0.117f)
          {
            result_array[7]=5;
          }
          else
          {
            result_array[7]=1;
          }
        }
        else
        {
          if (feature[26]<=42.38f)
          {
            result_array[7]=2;
          }
          else
          {
            result_array[7]=6;
          }
        }
      }
    }

    //  tree8
    if (feature[9]<=0.037f)
    {
      if (feature[11]<=0.359f)
      {
        if (feature[14]<=0.038f)
        {
          if (feature[3]<=0.115f)
          {
            result_array[8]=5;
          }
          else
          {
            result_array[8]=0;
          }
        }
        else
        {
          result_array[8]=3;
        }
      }
      else
      {
        result_array[8]=2;
      }
    }
    else
    {
      if (feature[13]<=0.119f)
      {
        result_array[8]=1;
      }
      else
      {
        if (feature[7]<=-0.232f)
        {
          if (feature[22]<=3.156f)
          {
            result_array[8]=7;
          }
          else
          {
            result_array[8]=6;
          }
        }
        else
        {
          if (feature[16]<=66.934f)
          {
            result_array[8]=6;
          }
          else
          {
            result_array[8]=7;
          }
        }
      }
    }

    //  tree9
    if (feature[12]<=0.05f)
    {
      if (feature[13]<=0.138f)
      {
        if (feature[23]<=16.663f)
        {
          if (feature[26]<=96.393f)
          {
            result_array[9]=1;
          }
          else
          {
            result_array[9]=0;
          }
        }
        else
        {
          if (feature[14]<=0.004f)
          {
            result_array[9]=5;
          }
          else
          {
            result_array[9]=4;
          }
        }
      }
      else
      {
        if (feature[28]<=28.591f)
        {
          result_array[9]=3;
        }
        else
        {
          result_array[9]=7;
        }
      }
    }
    else
    {
      if (feature[26]<=51.373f)
      {
        result_array[9]=2;
      }
      else
      {
        result_array[9]=6;
      }
    }

    for (i=0;i<10;i++)
		{
			if(result_array[i]==0)
			{
				decide_array[0]+=1;
			}
			else if(result_array[i]==1)
			{
				decide_array[1]+=1;
			}
			else if(result_array[i]==2)
			{
				decide_array[2]+=1;
			}
			else if(result_array[i]==3)
			{
				decide_array[3]+=1;
			}
			else if(result_array[i]==4)
			{
				decide_array[4]+=1;
			}
			else if(result_array[i]==5)
			{
				decide_array[5]+=1;
			}
			else if(result_array[i]==6)
			{
				decide_array[6]+=1;
			}
			else if(result_array[i]==7)
			{
				decide_array[7]+=1;
			}
		}
    
    temp = decide_array[0];
		n = 0;
		for(i =0;i<8;i++)
		{
			if(decide_array[i]>temp)
			{
				temp = decide_array[i];
				n = i;
			}
		}
			
			if(n==0)
			{
				result[n]+=1;
//				printf("headdown\r\n");
				printf("0\r\n");
			}
			if(n==1)
			{
				result[n]+=1;
//				printf("headup\r\n");
				printf("1\r\n");
			}
			if(n==2)
			{
				result[n]+=1;
//				printf("headright\r\n");
				printf("5\r\n");
			}
			if(n==3)
			{
				result[n]+=1;
//				printf("headleft\r\n");
				printf("4\r\n");
			}
			if(n==4)
			{
				result[n]+=1;
//				printf("head_turn_right\r\n");
				printf("3\r\n");
			}
			if(n==5)
			{
				result[n]+=1;
//				printf("head_turn_left\r\n");
				printf("2\r\n");
			}
			if(n==6)
			{
				result[n]+=1;
//				printf("head_right_ring\r\n");
				printf("7\r\n");
			}
			if(n==7)
			{
				result[n]+=1;
//				printf("head_left_ring\r\n");
				printf("6\r\n");
			}
		}
	}
	else if(flag1 == 2)
	{
//		printf("222\r\n");
	}
	
//		HAL_Delay(100);
//    printf("%d,%d,%d,%d,%d,%d,%d,%d\r\n",result[0],result[1],result[2],result[3],result[4],result[5],result[6],result[7]);
	}
}



/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
