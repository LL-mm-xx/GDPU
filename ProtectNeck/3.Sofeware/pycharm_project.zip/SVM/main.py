from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.model_selection import cross_val_score
import numpy as np
import pandas as pd
import joblib
from sklearn import svm


print('Generating Model')
# 选取随机数种子
np.random.seed(seed=10)
# 读取数据
inputs = pd.read_csv('../data/featuredata/total.csv', header=None)
outputs = pd.read_csv('../data/cuttingdata/tag.csv', header=None)


# 将数据顺序打乱
train = np.array(pd.concat([inputs, outputs], axis=1))
np.random.shuffle(train)
# 分成输入和结果
inputs = pd.DataFrame(train).iloc[:, :-1]
outputs = pd.DataFrame(train).iloc[:, -1]

mean = np.mean(inputs, axis=0)
std = np.std(inputs, axis=0)

inputs -= mean
inputs /= std

model = svm.SVC(kernel='linear', C=0.5)
model.fit(inputs, outputs)

# 提取参数
print(model.coef_.shape)
print(model.intercept_.shape)

b = model.intercept_
w = model.coef_
b = pd.DataFrame(b)
w = pd.DataFrame(w)
mean = pd.DataFrame(mean)
std = pd.DataFrame(std)
mean.to_csv('mean_normalise.csv')
std.to_csv('std_normalise.csv')
b.to_csv('bias_normalise.csv')
w.to_csv('weight_normalise.csv')