from scipy import signal
import numpy as np
import csv
import json
import pandas as pd


print('Preprocess Data')
# 打开原数据和将要写入的文件
name = ['accx', 'accy', 'accz', 'gyrx', 'gyry', 'gyrz', 'tag', 'total']
head_down_data = pd.read_csv('C:/Users/kzh/Desktop/Neck_posture_detection/Project/pycharm_project/data/processdata/headdown.csv')
head_up_data = pd.read_csv('C:/Users/kzh/Desktop/Neck_posture_detection/Project/pycharm_project/data/processdata/headup.csv')

for i1 in range(8):
    locals()[name[i1]] = open('C:/Users/kzh/Desktop/Neck_posture_detection/Project/pycharm_project/data/cuttingdata/' + name[i1] + '.csv', 'w', newline='')


#print(head_down_data)

# 主函数

for i2 in range(360):
    data = head_down_data.loc[i2]   # 逐行取数据
    for i3 in range(9):
        temp = data[i3 * 57: (i3 + 2) * 57]
        writer = csv.writer(locals()[name[7]])  # 写进total.csv
        writer.writerow(temp)

total_data = pd.read_csv('C:/Users/kzh/Desktop/Neck_posture_detection/Project/pycharm_project/data/cuttingdata/total.csv',header=None,names=range(0,114))  #
# x = total_data.iloc[0]
# print(x)


n3 = 0
for j2 in range(6):
    n2 = 0
    for j3 in range(60):
        n1 = 0
        for j4 in range(9):
            value = total_data.loc[n1+n2+n3]
            n1 = n1 + 1
            # print(value)
            w = csv.writer(locals()[name[j2]])  # 写进total.csv
            w.writerow(value)
        n2 = n2 + 54
    n3 = n3 + 9






print('Finish')