#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include "mqtt/qmqtt.h"
#include <QtNetwork>
#include <QHostAddress>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_connectBt_clicked();

    void on_subBt_clicked();

    void mqtt_connect_success();

    void mqtt_disconnect();

    void mqtt_sub_success();

    void mqtt_recv_msg(QMQTT::Message msg);

    void on_pubBt_clicked();


private:
    Ui::Widget *ui;
    QMQTT::Client *mqtt;
};
#endif // WIDGET_H
