#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_connectBt_clicked()
{
    mqtt = new QMQTT::Client(QHostAddress(QString(ui->hostLe->text())),ui->portLe->text().toInt());
    connect(mqtt, SIGNAL(connected()), this, SLOT(mqtt_connect_success()));
    connect(mqtt, SIGNAL(disconnected()), this, SLOT(mqtt_disconnect()));
    connect(mqtt, SIGNAL(subscribed(QString,quint8)), this, SLOT(mqtt_sub_success()));
    connect(mqtt, SIGNAL(received(QMQTT::Message)), this, SLOT(mqtt_recv_msg(QMQTT::Message)));

    mqtt->setClientId("Qt-test0x10");
    mqtt->setUsername("admin");
    mqtt->setPassword("public");

    mqtt->setCleanSession(true);
    mqtt->connectToHost(); //连接mqtt
}

void Widget::mqtt_connect_success() //连接成功
{
    ui->textBrowser->append(QObject::tr("连接成功"));
}

void Widget::mqtt_disconnect() //连接断开
{
    ui->textBrowser->append("连接断开");
}

void Widget::mqtt_sub_success() //订阅成功
{
    QString msg = "订阅主题 ";
    msg += ui->subthemeLe->text();
    msg += " 成功";
    ui->textBrowser->append(msg);
}

void Widget::mqtt_recv_msg(QMQTT::Message msg) //接收消息处理
{
    QString recv_msg = "Topic:";
    QString data = msg.payload();
    recv_msg += msg.topic();
    recv_msg += "    Payload:";
    recv_msg += data;
    ui->textBrowser->append(recv_msg);
}

void Widget::on_pubBt_clicked()
{
    QMQTT::Message msg;
    msg.setTopic(ui->pubthemeLe->text());
    msg.setPayload(ui->pubMsgLe->text().toLocal8Bit());
    mqtt->publish(msg);
}

void Widget::on_subBt_clicked()
{
    mqtt->subscribe(ui->subthemeLe->text(),1);
}
