/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QWidget *widget;
    QGridLayout *gridLayout;
    QHBoxLayout *horizontalLayout;
    QLabel *label;
    QLineEdit *hostLe;
    QPushButton *connectBt;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_3;
    QLineEdit *portLe;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_4;
    QLineEdit *subthemeLe;
    QPushButton *subBt;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_2;
    QLineEdit *pubthemeLe;
    QHBoxLayout *horizontalLayout_5;
    QLabel *label_5;
    QLineEdit *pubMsgLe;
    QPushButton *pubBt;
    QTextBrowser *textBrowser;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(364, 502);
        widget = new QWidget(Widget);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(10, 10, 341, 481));
        gridLayout = new QGridLayout(widget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));

        horizontalLayout->addWidget(label);

        hostLe = new QLineEdit(widget);
        hostLe->setObjectName(QString::fromUtf8("hostLe"));

        horizontalLayout->addWidget(hostLe);


        gridLayout->addLayout(horizontalLayout, 0, 0, 1, 1);

        connectBt = new QPushButton(widget);
        connectBt->setObjectName(QString::fromUtf8("connectBt"));

        gridLayout->addWidget(connectBt, 0, 1, 2, 2);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        label_3 = new QLabel(widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_2->addWidget(label_3);

        portLe = new QLineEdit(widget);
        portLe->setObjectName(QString::fromUtf8("portLe"));

        horizontalLayout_2->addWidget(portLe);


        gridLayout->addLayout(horizontalLayout_2, 1, 0, 1, 1);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_4 = new QLabel(widget);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        horizontalLayout_3->addWidget(label_4);

        subthemeLe = new QLineEdit(widget);
        subthemeLe->setObjectName(QString::fromUtf8("subthemeLe"));

        horizontalLayout_3->addWidget(subthemeLe);


        gridLayout->addLayout(horizontalLayout_3, 2, 0, 1, 2);

        subBt = new QPushButton(widget);
        subBt->setObjectName(QString::fromUtf8("subBt"));

        gridLayout->addWidget(subBt, 2, 2, 2, 1);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout_4->addWidget(label_2);

        pubthemeLe = new QLineEdit(widget);
        pubthemeLe->setObjectName(QString::fromUtf8("pubthemeLe"));

        horizontalLayout_4->addWidget(pubthemeLe);


        gridLayout->addLayout(horizontalLayout_4, 3, 0, 1, 2);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        label_5 = new QLabel(widget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_5->addWidget(label_5);

        pubMsgLe = new QLineEdit(widget);
        pubMsgLe->setObjectName(QString::fromUtf8("pubMsgLe"));

        horizontalLayout_5->addWidget(pubMsgLe);


        gridLayout->addLayout(horizontalLayout_5, 4, 0, 1, 2);

        pubBt = new QPushButton(widget);
        pubBt->setObjectName(QString::fromUtf8("pubBt"));

        gridLayout->addWidget(pubBt, 4, 2, 1, 1);

        textBrowser = new QTextBrowser(widget);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));

        gridLayout->addWidget(textBrowser, 5, 0, 1, 3);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", nullptr));
        label->setText(QApplication::translate("Widget", "\344\270\273\346\234\272\357\274\232", nullptr));
        connectBt->setText(QApplication::translate("Widget", "\350\277\236\346\216\245", nullptr));
        label_3->setText(QApplication::translate("Widget", "\347\253\257\345\217\243\357\274\232", nullptr));
        label_4->setText(QApplication::translate("Widget", "\350\256\242\351\230\205\344\270\273\351\242\230\357\274\232", nullptr));
        subBt->setText(QApplication::translate("Widget", "\350\256\242\351\230\205", nullptr));
        label_2->setText(QApplication::translate("Widget", "\345\217\221\345\270\203\344\270\273\351\242\230\357\274\232", nullptr));
        label_5->setText(QApplication::translate("Widget", "\345\217\221\345\270\203\345\206\205\345\256\271\357\274\232", nullptr));
        pubBt->setText(QApplication::translate("Widget", "\345\217\221\345\270\203", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
